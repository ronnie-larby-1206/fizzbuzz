This is a Maven project which generates an executable war file. There are two ways to run the Main class.

1. Create a directory called FizzBuzzTest3 on your c/d drive and extract the contents of the FizzBuzzTest3.zip file into this directory. 
Load into an IDE and then run the FizzBuzzMain.class i.e. right click the FizzBuzzMain.java file and choose run as --> Java Application. 
Results will be shown on the console. You can change the run time parameters by changing them in the FizzBuzzMain.java file, saving them
and then running again as before.

2. Create a directory called FizzBuzzTest3 on your c/d drive and copy the FizzBuzz-0.0.3-SNAPSHOT-jar-with-dependencies.jar artefact
from the target directory in this project. Open a command window in the FizzBuzzTest3 directory and run with the command
java -jar FizzBuzz-0.0.3-SNAPSHOT-jar-with-dependencies.jar. This was built in java 8 so that must be the version of java running 
 on your pc.