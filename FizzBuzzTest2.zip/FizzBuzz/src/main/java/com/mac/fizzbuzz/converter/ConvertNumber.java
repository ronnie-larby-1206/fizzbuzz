/**
 * 
 */
package com.mac.fizzbuzz.converter;

import java.util.List;

import com.mac.fizzbuzz.exception.FizzBuzzParametersException;

/**
 * @author Ronnie Larby
 *
 */
public interface ConvertNumber {
	
	public static final String SPACE_DELIMITER = " ";
	
	public String convert(List<Integer> divisors, Integer fromNumber, Integer toNumber) throws FizzBuzzParametersException;

}
